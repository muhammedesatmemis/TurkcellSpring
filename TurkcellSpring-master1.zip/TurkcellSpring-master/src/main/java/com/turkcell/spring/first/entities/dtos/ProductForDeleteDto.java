package com.turkcell.spring.first.entities.dtos;

import lombok.Data;

@Data
public class ProductForDeleteDto {

    private int productId;
}
