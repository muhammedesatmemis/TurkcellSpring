3.kısımda kod çalışıyor ama database'e ekleme yapmıyor
5.kısımda hata mesajı dönüyor 